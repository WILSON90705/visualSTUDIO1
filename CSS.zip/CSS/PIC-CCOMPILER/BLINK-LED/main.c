#include <18f4550.h>
#use_delay(clock=8000000)

void main()
{

   while(TRUE)
   {
      //TODO: User Code
   }

}
