#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int suma=0;
	int cuenta=0;
	float promedio;
	int notas=0;
	int acumulador=0;
	float num_notas;
	cout<<"dime el numero de notas";
	cin>>num_notas;
	cuenta=0;
	do{
		cout<<"tu notas dimelas";
		cin>>notas;
		acumulador+=notas;
	    cuenta++;	
	}
	while(cuenta<num_notas);
	promedio=acumulador/num_notas;
	cout<<"tu promedio es"<<promedio;
	
}
