/* Una persona enferma, que pesa 70 kg, se encuentra en reposo y desea saber cu�ntas calor�as consume su cuerpo durante todo el tiempo que realice una misma 
actividad. Las actividades que tiene permitido realizar son �nicamente dormir o estar sentado en reposo.
Los datos que tiene son que estando dormido consume 1.08 calor�as por minuto y estando sentado en reposo consume 1.66 calor�as por minuto.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
float CALORIAS;
int peso=70;
int ACTIVIDAD;
int DORMIDO=1;
int REPOSO=2;  
int TEMP;
cout<<"dime la actividad del paciente en cuestion por favor";
cin>>ACTIVIDAD;
cout<<"dime el tiempo de la actividad";
cin>>TEMP;
if(ACTIVIDAD==1){
	CALORIAS=TEMP*1.08;
}
else if(CALORIAS==2){
	CALORIAS=TEMP*1.66;
}
cout<<"tus calorias son"<<CALORIAS;
}
