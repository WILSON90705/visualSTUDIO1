/*
Una persona desea iniciar un negocio,
para lo cual piensa verificar cu�nto dinero le prestara el banco por hipotecar su casa.
Tiene una cuenta bancaria,pero no quiere disponer de ella a menos que el monto
por hipotecar su casa sea muy peque�o.
 Si el monto de la hipoteca es menor que $1,000 000 entonces invertir� el 50% de la inversi�n total y un socio
 invertir� el otro 50%.Si el monto de la hipoteca es de $ 1,000 000 o m�s,
 entonces invertir� el monto total de la hipoteca
 y el resto del dinero que se necesite para cubrir la inversi�n total se repartir� a partes iguales
entre el socio y el.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int PRESTAMO;
	int MONTO_HIPOTECA;
	float INVERSION;
	cout<<"dime el MONTO DE LA HIPOTECA";
	cin>>MONTO_HIPOTECA;
	
	if(MONTO_HIPOTECA<1000000){
	
	}
	else if(MONTO_HIPOTECA>=1000000){
		
	}
}
