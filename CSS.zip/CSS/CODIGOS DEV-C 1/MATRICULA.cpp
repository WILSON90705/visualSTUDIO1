/*
En una escuela la colegiatura de los alumnos se determina seg�n el n�mero de materias que cursan
 El costo de todas las materias es el mismo.
 Se ha establecido un programa para estimular a los alumnos, el cual consiste en lo siguiente:
 si el promedio obtenido por un alumno en el �ltimo periodo es mayor o igual que 9,
 se le har� un descuento del 30% sobre la colegiatura y no se le cobrara IVA;
 si el promedio obtenido es menor que 9 deber� pagar la colegiatura completa,
 la cual incluye el 10% de IVA.Obtener cuanto debe pagar un alumno.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int promedio;
	int matricula;
	float pago,IVA;
	cout<<"dime la matricula del estudiante";
	cin>>matricula;
	cout<<"dime el promedio de dicha persona por favor";
	cin>>promedio;
	if(promedio>=9){
		pago=matricula*0.30;
	}
	else{
		pago=matricula+matricula*0.10;	
	}
	
	cout<<"tu pago es: "<<pago;
	
	
	
	
	
	
}
