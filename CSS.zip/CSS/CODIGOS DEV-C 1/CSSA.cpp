/*   Una empresa quiere hacer una compra de varias piezas de la misma clase a una f�brica de refacciones.
La empresa, dependiendo del monto total de la compra, decidir� qu� hacer para pagar al fabricante. Si el monto total de la compra
excede de $500 000 la empresa tendr� la capacidad de invertir de su propio  dinero un 55% del monto de la compra,
pedir prestado al banco un 30% y el resto lo pagara solicitando un cr�dito al fabricante. Si el monto total de la compra
no excede de $500 000 la empresa tendr� capacidad de invertir de su propio dinero un 70% y el restante 30% lo pagara solicitando cr�dito al fabricante
El fabricante cobra por concepto de intereses un 20% sobre la cantidad que se le pague a cr�dito.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
float MONTO_TOT_COMPRA;
int PIEZAS;
int COSTO;
float INVERSION;
float intereses;
float PRESTAMO;
float RESTO;
float INTER;
float CREDITO;
cout<<"dime el cuanto cuestan klas piezas";
cin>>COSTO;
cout<<"dime el numero de piezas";
cin>>PIEZAS;
MONTO_TOT_COMPRA=COSTO*PIEZAS;
if(MONTO_TOT_COMPRA<500000){
	INVERSION=MONTO_TOT_COMPRA*0.55;
	PRESTAMO=MONTO_TOT_COMPRA*0.30;
	RESTO=MONTO_TOT_COMPRA*0.15;
	cout<<"TU INVERSION ES"<<INVERSION;
}
else{
	
	INVERSION=MONTO_TOT_COMPRA*0.70;
	CREDITO=MONTO_TOT_COMPRA*0.30;
	PRESTAMO=0;
		
}
INTER=CREDITO*0.20;
cout<<"los intereses son"<<INTER;
cout<<"EL PRESTAMO ES"<<PRESTAMO;
cout<<"el credito es"<<CREDITO;
cout<<"la inversion es"<<INVERSION;
}
