/*
Una persona dese ir a desayunar, comer o cenar a un establecimiento. Con lo cual encuentra
Horario desayuno de 9 a 11, comida de 13 a 17 y cena de 19 a 21.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int HORAS;
	cout<<"PORFAVOR DIME LA HORA";
	cin>>HORAS;
	if(HORAS>24){
		cout<<"HORA INCORRECTA DI UNA HORA CORRECTA";
	}
	else if(HORAS>=9 && HORAS<=11 ){
cout<<"TE TOCA DESAYUNAR";		
	}
	else if(HORAS>=13 && HORAS<=17){
		cout<<"TE TOCA LA CENA DE MEDIO DIA";
	}
	else if(HORAS>=19 && HORAS<=21){
		cout<<"TE TOCA CENAR LA ULTIMA COMIDA";
	}
	else{
		
	cout<<"NO HAY SERVICIO";
	}
	
	
	
	
	
	
}
