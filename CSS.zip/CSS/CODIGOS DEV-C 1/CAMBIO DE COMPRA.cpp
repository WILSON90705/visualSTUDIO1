#include<iostream>
#include<conio.h>
using namespace std;
int main(){
	int PRECIO,PAGO;
	int TOT;
	int A;
	cout<<"dime por favor el precio del producto";
	cin>>PRECIO;
	cout<<"dime el pago de la persona";
	cin>>PAGO;
     if(PAGO>=PRECIO){
     	TOT=PAGO-PRECIO;
     	cout<<"el cambio tuyo es"<<TOT;
	 }	
	 else{
	 	A=PRECIO-PAGO;
	 	cout<<"NO TE ALCANZA PARA REALIZAR LA COMPRA"<<A;
	 }
	
	
	
	
	
	
	
	
	
	
	
	
	
}
