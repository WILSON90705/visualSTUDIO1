#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int suma=0;
	int cuenta=0;
	float promedio;
	int notas=0;
	int acumulador=0;
	float n;
	cout<<"dime el numero de notas";
	cin>>n;
	for(cuenta=0;cuenta<n;cuenta++){
		cout<<"tu notas dimelas";
		cin>>notas;
		acumulador=acumulador+notas;
	}
	promedio=acumulador/n;
	cout<<"TU PROM ES"<<promedio;
}
