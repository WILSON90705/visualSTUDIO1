#include<iostream>
#include<conio.h>
using namespace std;
int main(){
	float PROM,DESC,TOT;
	char X;
	int MAT;
	cout<<"DIME POR FAVOR TU PROMEDIO";
	cin>>PROM;
	cout<<"DIME QUE ERES DE PROFESIONAL(P) O PREPARATORIA(A)";
	cin>>X;
	if(X=='A'){
		if(PROM>=9.5){
			TOT=((55/5)*180);
			DESC=TOT*0.25;
		}
		else if(PROM>=9 && PROM>9.5){
			TOT=((50/5)*180);
			DESC=TOT*0.10;
		}
		else if(PROM>7&&PROM<9){
			TOT=((50/5)*180);
			DESC=0;
		}
		else if(PROM<=7){
			cout<<"tu numero de materias perdidas es entre 0 y 3";
			TOT=((40/5)*180);;
			DESC=0;
		}
	}
		if(X=='P'){
		 if(PROM>=9.5){
			TOT=(55/5)*300;
			DESC=TOT*0.20;
		}
		
		else if(PROM<9.5){
		TOT=(55/5)*300;
		DESC=0;
		
	}
}
cout<<"TU DES ES"<<DESC;
cout<<"TU TOT ES"<<TOT;
}

	
	
	
