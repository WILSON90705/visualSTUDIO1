/*
El gobierno ha establecido el programa SAR (Sistema de Ahorro para el Retiro)
que consiste en que los due�os de la empresa deben obligatoriamente depositar
en una cuenta bancaria un porcentaje del salario de los trabajadores;
adicionalmente los trabajadores pueden solicitar a la empresa que deposite directamente una cuota fija o
un porcentaje de su salario en la cuenta del SAR,la cual le ser� descontada de su pago.
Un trabajador que ha decidido aportar a su cuenta del SAR desea saber la cantidad total de dinero
que estar� depositado a esa cuenta cada mes,y el pago mensual que recibir�.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int PAGO_MENSUAL;
	int TOTAL;
	int SALARIO,J;
	cout<<"dime el tu salario";
	cin>>SALARIO;
	cout<<"DESEAS USAR EL S.A.R  DALE 1 si quieres y si no 0";
	cin>>J;
	if(J==1){
	TOTAL=SALARIO+SALARIO*30;
	PAGO_MENSUAL=SALARIO*30;
	}
	cout<<"dime el total"<<TOTAL;
	cout<<"dime el pago_mensual"<<PAGO_MENSUAL;
}
