#INCLUDE <16f877A.h>
#fuses XT, NOWDT, PUT, BROWNOUT,NOLVP
#use delay(clock=4000000)
#DEFINE SWIT PIN_A0
#DEFINE LED  PIN_C0
void main(){
set_tris_a(1);
set_tris_C(0);
while(1){
if(input(PIN_A0)==1){
output_high(PIN_C0);
}
else{
output_low(PIN_C0);
}
}
}
