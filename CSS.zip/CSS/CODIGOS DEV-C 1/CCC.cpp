/*  En un almac�n se hace un 20% de descuento a los clientes cuya compra supere los $1000
�Cu�l ser� la cantidad que pagara una persona por su compra?  */
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int COMP;
	double A=0.20;
	int PAG;
	int TOT;
	int DESC;
	cout<<"dime tu compra por favor";
	cin>>COMP;
	if(COMP>1000){
		DESC=COMP*0.20;
	}
	else{
		DESC=0;
	}
	TOT=COMP-DESC;
	cout<<"TU TOTAL ES"<<TOT;
}
