/*Escribir un algoritmo que, ingrese varias calificaciones del 1 al 10, ingrese una categor�a para cada rango de calificaci�n que se indica a continuaci�n.
Calificaci�n de 1 a 4 = �REPROBADO�
Calificaci�n mayor a 4 y menor o igual a  7 = �REGULAR�
Calificaci�n mayor a 7  y menor o igual a 8 = �BUENO�
Calificaci�n mayor a 8 y menor o igual a 9 = �MUY BUENO�
Calificaci�n mayor a 9                                     = �EXCELENTE�
Al finalizar, deber� mostrar por pantalla
Total de notas ingresadas
Total de alumnos de la categor�a REPROBADOS
Total de alumnos de la categor�a REGULAR
Total de alumnos de la categor�a BUENO
Total de alumnos de la categor�a MUY BUENO
Total de alumnos de la categor�a EXCELENTE*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int CALF[5],i=0;
	for(int i=1;i<5;i++){
		cout<<"dame tus calificaciones\n";
		cin>>CALF[i];
		
	}
	for(int i=1;i<=5;i++){ //REPROBADOS
		if(CALF[i]<=4){
			cout<<"REPROBADO\n"<<CALF[i];
		}
	}
	for(int i=1;i<=5;i++){ 
		if(CALF[i]>4  && CALF[i]<=7){
			cout<<"ACEPTABLE"<<CALF[i];	
		}
	}
	for(int i=1;i<=5;i++){
		if(CALF[i]>7 && CALF[i]<=8){
			cout<<"BUENO"<<CALF[i];
		}
	}
	for(int i=1;i<=5;i++){
		if(CALF[i]>8 && CALF[i]<=9){
			cout<<"MUY BUENO"<<CALF[i];
		}
	}
	for(int i=1;i<=5;i++){
		if(CALF[i]>=9){
			cout<<"EXCELENTE"<<CALF[i];
		}
	}
}
