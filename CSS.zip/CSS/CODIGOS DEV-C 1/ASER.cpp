/*
Calcular el total que una persona debe pagar en una llantera
si el precio de cada llanta es de $800 si se compran menos de 5 llantas y de $700 si se compran 5 o m�s.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int CANTIDAD;
	int PRECIO1=800;
	int precio2=700;
	cout<<"dime el numero de llantas que vas a comprar";
	cin>>CANTIDAD;
	if(CANTIDAD<5){
		cout<<"lo que debes pagar es"<<PRECIO1;
	}
	else if(CANTIDAD>=5){
		cout<<"lo que debes pagar es"<<precio2;
	}
	
	
	
	
}
