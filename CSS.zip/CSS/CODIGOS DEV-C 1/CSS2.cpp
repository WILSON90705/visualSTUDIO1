/*Un hombre desea saber cu�nto dinero se genera por concepto de intereses sobre la cantidad que tiene en inversi�n en el banco.
El decidir� reinvertir los intereses siempre y cuando estos excedan a $7000, y en ese caso desea saber cu�nto dinero tendr� finalmente en su cuenta
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int inter,cap;
	int p_inter;
	int total;
	cout<<"dime tus porcentaje de intereses";
	cin>>inter;
	cout<<"dime tu cap";
	cin>>cap;
	inter=p_inter*cap;
	if(inter>7000){
		total=cap+inter;
		
	}
		cout<<"tu capital es "<<total;
}
