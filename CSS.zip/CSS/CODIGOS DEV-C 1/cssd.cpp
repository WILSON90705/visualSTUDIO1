/*     Leer 2 n�meros; si son iguales que los multiplique, si el primero es mayor que el segundo que los reste y si no que los sume.      */
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int NUM1;
	int NUM2;
	int NUM3;
	cout<<"dime los numeros 1";
	cin>>NUM1;
	cout<<"dime los numeros 2";
	cin>>NUM2;
	if(NUM1==NUM2){
		NUM3=NUM1*NUM2;
	}
else if(NUM1>NUM2){
	NUM3=NUM1-NUM2;

}	
else if(NUM2>NUM1){
	NUM3=NUM2+NUM1;
	
}	
	cout<<"el numero es"<<NUM3;
	
	
	
}
