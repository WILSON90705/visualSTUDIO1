#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int suma=0;
	int cuenta=0;
	float promedio;
	int notas=0;
	int acumulador=0;
	float num_notas;
	int MAT;
	cout<<"dime por favor materia a calcular promedio 1:es matematicas,2:espa�ol,3:ingles";
	cin>>MAT;
	switch(MAT){
		
		case 1:
			cout<<"OPCION MATEMATICAS\n";
			for(cuenta=1;cuenta<=5;cuenta++){
		cout<<"tu notas dimelas";
		cin>>notas;
		acumulador=acumulador+notas;
	}
	promedio=acumulador/5;
	cout<<"TU PROM ES"<<promedio;
	break;
	case 2:
		cout<<"OPCION ESPA�OL\n";
		cuenta=0;
	while(cuenta<num_notas){
		cout<<"tu notas dimelas";
		cin>>notas;
		acumulador+=notas;
		cuenta++;
	}
	promedio=acumulador/num_notas;
	cout<<"TUS PROM SON"<<promedio;
			break;
		case 3:
			cout<<"OPCION INGLES\n";
			cuenta=0;
	do{
		cout<<"tu notas dimelas";
		cin>>notas;
		acumulador+=notas;
	    cuenta++;	
	}
	while(cuenta<num_notas);
	promedio=acumulador/num_notas;
	cout<<"tu promedio es: "<<promedio;
	}
	
	
}
