/*   Un obrero necesita calcular su salario semanal, el cual se obtiene de la siguiente manera: Si trabaja 40 horas o menos se le paga un salario de $16 por hora
 si trabaja m�s de 40 horas se le paga un salario de $16 por cada una de las primeras 40 horas y un salario de $20 por cada hora extra   */
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int ss,HRS,HEX;
	cout<<"dime tus horas trabajadas";
	cin>>HRS;
	if(HRS>40){
		HEX=HRS-40;
		ss=HEX*20+40*16;
	}
	else{
		ss=HRS*16;
	}
	cout<<"tus horas trabajadas son"<<ss;
	
}
