
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	float TEMP;
	float UT_TOTAL;
	float SALA;
	cout<<"DIME EL SALARIO MENSUAL DEL TRABAJADOR";
	cin>>SALA;
	cout<<"DAME EL TIEMPO del trabajador";
	cin>>TEMP;
	if(TEMP<1){
		UT_TOTAL=SALA*0.05;
	}
    if(TEMP>=1 && TEMP>2){
    	UT_TOTAL=SALA*0.07;
	}
	if(TEMP>=2 && TEMP>5){
		UT_TOTAL=SALA*0.10;
	}
	if(TEMP>=5 && TEMP>10){
		UT_TOTAL=SALA*0.15;
	}
    if(TEMP>=10){
		UT_TOTAL=SALA*0.20;
	}
	cout<<"LA UTILIDAD DEL TRABAJADOR"<<UT_TOTAL;
}
