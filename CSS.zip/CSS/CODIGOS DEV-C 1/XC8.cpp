
#include <iostream>
#include <conio.h>
using namespace std;
int main(){

int Ss,HORAS;
int HEX;
cout<<"dime las horas de TRABAJO";
cin>>HORAS;
if(HORAS<=40){
Ss=16*HORAS;
}
else if(HORAS>40){	
HEX=HORAS-40;
Ss=40*16+20*HEX;
}
cout<<"tu salario es"<<Ss<<endl;



}
