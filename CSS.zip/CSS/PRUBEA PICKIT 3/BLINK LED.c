#include <16F877A.h>
#FUSES HS,NOPROTECT,NOWDT,NOBROWNOUT,PUT,NOLVP
#use delay (clock=20000000)
#define led pin_B5
void main()
{
set_tris_B(0x00);
   while(TRUE)
   {
    output_high(led);    // Toggle output pin RB0
    delay_ms(500);
    output_low(led);
    delay_ms(500);
   }
}
