#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int salario, sar, porcentaje;
	int x;
	int pago_mensual;
	cout<<"dime tu salario por favor";
	cin>>salario;
	cout<<" ingresa la opcion 1=cuota fija o 2=porcentaje";
	cin>>x;
	
	if(x==1 or x==2){
		if(x==1){
			cout<<"dime por favor la cuota del SAR";
			cin>>sar;
		}
		else{
			cout<<"ingresa un porcentaje del dinero del SAR";
			cin>>porcentaje;
			sar=(salario*porcentaje)/100;
		}
		pago_mensual=salario-sar;
		cout<<"tu SAR ES"<<sar;
		cout<<"tu pago mensual"<<pago_mensual;
    }
}
