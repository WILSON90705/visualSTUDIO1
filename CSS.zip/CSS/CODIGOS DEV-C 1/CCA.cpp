/*       
Una empresa de bienes ra�ces ofrece casas de inter�s social
bajo las siguientes condiciones: Si los ingresos del comprador son menores de $8000
el enganche ser� del 15% del costo de la casa y el resto se distribuir� en pagos mensuales, a pagar en diez a�os
Si los ingresos del comprador son igual o mayores de $8000 
el enganche ser� del 30% del costo de la casa y el resto se distribuir� en pagos mensuales a pagar en 7 a�os.
La empresa quiere obtener cuanto debe pagar un comprador por concepto de enganche
y cuanto por cada pago parcial.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int ingresos;
	float pagos_enganche;
	float pagos_parcial;
	float RESTANTE;
	cout<<"dime por una parte de tus ingresos";
	cin>>ingresos;
	if(ingresos<8000){
	pagos_enganche=ingresos*0.15;
	pagos_parcial=ingresos*120;
	}
	else if(ingresos>=8000){
	pagos_enganche=ingresos*0.30;
	pagos_parcial=ingresos*84;		
	}
	cout<<"los de enganche son"<<pagos_enganche;
	cout<<"los pagos parcial"<<pagos_parcial;	
}
