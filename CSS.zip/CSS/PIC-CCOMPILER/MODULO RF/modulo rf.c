#include <16f877A.h>
#fuses HS, NOWDT, NOPROTECT, BROWNOUT, PUT, NOLVP
#use delay(clock=20M,crystal)
#use i2c(Master,Fast=100000, sda=PIN_C4, scl=PIN_C3,force_sw)
#include "i2c_Flex_LCD.c"
#use standard_io(C)
#use standard_io(D)
int valor,val;
void main(){
lcd_init(0x4E,16,2);
lcd_backlight_led(ON); 
set_tris_D(0b1000000);
while(1){
if(PIN_D7==1){
lcd_gotoxy(2,2);
lcd_putc("wilson");
delay_ms(1000);
}
}
}
