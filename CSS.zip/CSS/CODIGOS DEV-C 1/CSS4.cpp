/* Determinar si un alumno aprueba a reprueba un curso, sabiendo que aprobara si su promedio de tres calificaciones es mayor o igual a 70
reprueba en caso contrario.  */
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
int CALF[3],SUM,PROM;
for(int i=0;i<3;i++){
	cout<<"dime tus notas";
	cin>>CALF[i];
}	
for(int i=0;i<3;i++){
	SUM+=CALF[i];
}
PROM=SUM/3;
if(PROM>=7){
	cout<<"BIEN";
}
else{
	cout<<"REPROBASTE";
}

}
