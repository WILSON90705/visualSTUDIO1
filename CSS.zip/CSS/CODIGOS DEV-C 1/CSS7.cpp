/* Que lea dos n�meros y los imprima en forma ascendente */
#include<iostream>
#include <conio.h>
using namespace std;
int main(){
	int NUM1,NUM2;
	cout<<"dime cual es el numero mayor";
	cin>>NUM1;
	cout<<"dime cual es el numero menor";
	cin>>NUM2;
	if(NUM1>NUM2){
		cout<<"el numero mayor es"<<NUM1<<NUM2<<endl;
	}
	else {
		cout<<"el numero mayor es"<<NUM2<<NUM1<<endl;
	}
	
	
}
