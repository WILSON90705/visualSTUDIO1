/* Hacer un algoritmo que imprima el nombre de un art�culo, clave, precio original y su precio con descuento  
El descuento lo hace en base a la clave, si la clave es 01 el descuento es del 10% y si la clave es 02 el descuento en del 20%
(solo existen dos claves).
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int CLAVE;
	char NOMBRE;
	int precio_OR;
	float precio_
}
