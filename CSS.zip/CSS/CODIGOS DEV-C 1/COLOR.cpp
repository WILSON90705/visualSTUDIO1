/*
En una tienda de descuento se efect�a una promoci�n en la cual se hace un descuento
sobre el valor de la compra total seg�n el color de la bolita que el cliente saque al pagar en caja.
Si la bolita es de color blanco no se le har� descuento alguno,
si es verde se le har� un 10% de descuento, si es amarilla un 25%,
si es azul un 50% y si es roja un 100%.
Determinar la cantidad final que el cliente deber� pagar por su compra se sabe que solo hay bolitas de los colores
mencionados.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
int PC;
int DESC;
char color;
cout<<"dime color";
cin>>color;
if(color="BLANCA"){
	DESC=0;
}
	
	
	
	
	
	
	
	
	
}
