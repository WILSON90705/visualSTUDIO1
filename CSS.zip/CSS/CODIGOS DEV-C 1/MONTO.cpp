/*
Una compa��a de seguros est� abriendo un depto. de finanzas y estableci� un programa para captar clientes, que consiste en lo siguiente:
 Si el monto por el que se efect�a la fianza es menor que $50 000 la cuota a pagar ser� por el 3% del monto,
 y si el monto es mayor que $50 000 la cuota a pagar ser� el 2% del monto.
 La afianzadora desea determinar cu�l ser� la cuota que debe pagar un cliente.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int monto;
	float pago;
	cout<<"dime el monto de la operacion";
	cin>>monto;
	if(monto<50000){
		
		pago=monto*0.03;
	}
	else if(monto>=50000){
		pago=monto*0.02;
	}
	cout<<"tu pago es: "<<pago;
}
