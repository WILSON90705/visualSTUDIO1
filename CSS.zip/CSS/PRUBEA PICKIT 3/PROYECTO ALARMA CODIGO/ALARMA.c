#include<16f877A.h>
#FUSES XT,NOPROTECT,NOWDT,NOBROWNOUT,PUT,NOLVP
#USE DELAY(CLOCK=4M)
#define LCD_DB4 pin_D4
#define LCD_DB5 PIN_D5
#define LCD_DB6 PIN_D6
#define LCD_DB7 PIN_D7
#define LCD_RS PIN_D1
#define LCD_RW PIN_D2
#define LCD_E PIN_D0
#include <flex_lcd.c>
#include <kbd_lib.c>
#use standard_IO(A)
#use RS232(BAUD=9600,BITS=8,PARITY=N,XMIT=PIN_C6,RCV=PIN_C7)
#DEFINE SWIT PIN_A0
#DEFINE LED  PIN_A1
#rom 0x2100={'1','2','3','4'} // escribir en la memoria eeprom
int i;
int j=0;
int d=0;
char k; 
char dato[4],clave[4]; 
void MAIN(){
inicio:
lcd_init(); 
kbd_init(); 
set_tris_a(0b00000001);
port_b_pullups(TRUE);
for(;;){
lcd_putc("\f  BIENVENIDO ");  //
lcd_putc("\n sistema alarma ");
delay_ms(1000);
//lcd_putc("\f  wilson "); 
delay_ms(1000);
lcd_putc("\fDIME TU CLAVE  ");
output_low(PIN_C0);
output_low(PIN_C1);
i=0;
while(i<4){
k=kbd_getc(); 
if(k!=0){
      dato[i]=k; 
      i++;
      lcd_gotoxy((i+3),2);
      lcd_putc('*');
      output_low(PIN_A1);
      output_high(PIN_C1);
      delay_ms(15);
      output_low(PIN_C1);
      
if(K=='#')
      {
      lcd_putc("\fCambio de clave! ");
      delay_ms(2000);
       lcd_putc("\fDigite clave \nanterior");
       i=0;
       while(i<4){//lee el teclado nuevamente
       k=kbd_getc(); // leer la tecla presiono 
       if(k!=0){
       dato[i]=k; 
       i++;
       lcd_gotoxy((i+10),2); // posicion i de la segunda linea 
       lcd_putc('*');
      output_high(PIN_C1);
      delay_ms(15);
      output_low(PIN_C1);
        }
         }
         
   for(i=0;i<4;i++)
   clave[i]=read_eeprom(i); //guarda la constrase�a  en el vector clave 
   
   if( dato[0]==clave[0] &&  dato[1]==clave[1] && dato[2]==clave[2] && dato[3]==clave[3])
   {  
      lcd_putc("\fClave Correcta! ");
      delay_ms(2000);
      lcd_putc("\fdigite nueva \nclave");
      /////////////////////////////////////////
      clave:
      i=0;
      while(i<4){
      k=kbd_getc(); 
      if(k!=0){
      dato[i]=k; 
      i++;
      lcd_gotoxy((i+8),2); // posicion i de la segunda linea 
      lcd_putc('*');
      output_high(PIN_C1);
      delay_ms(15);
      output_low(PIN_C1);
        }
         }
         for(d=0; d<=4;d++)  //vamos a gravar los datos en la eeprom del pic
            {
              write_eeprom(d,dato[d]);//paso las teclas de clave a la eeprom del pic
                
            } 
            lcd_putc("\fsu clave a sido \ncambiada :) ");
            delay_ms(2000);
            break;
        
   }
   else{
      lcd_putc("\fClave incorrecta ");
      j++;
      if(j==3){
      lcd_putc("\fSistema \n  Bloqueado ");
      delay_ms(60000);
      j=0;
      }
      for(int d=0;d<10;d++)
      {
      output_high(PIN_C1);
      delay_ms(100);
      output_low(PIN_C1);
      delay_ms(100);
      output_low(PIN_C0);
      }
     
      }
      goto clave;
      }//cierre numeral cambio de clave
      
       for(i=0;i<4;i++)
   clave[i]=read_eeprom(i); //guarda la constrase�a  en el vector clave 
   
   if( dato[0]==clave[0] &&  dato[1]==clave[1] && dato[2]==clave[2] && dato[3]==clave[3])
   {  
      lcd_putc("\fClave Correcta! ");
      lcd_putc("\nAdelante!!  ");
      output_high(PIN_C0);
      output_low(PIN_C1);
      delay_ms(2000);
      output_low(PIN_C0);
   
   }
   else{
      lcd_putc("\fClave incorrecta ");
      delay_ms(10000);
      j++;
      break;
      if(j==3){
      lcd_putc("\fSistema \n  Bloqueado ");
      delay_ms(60000);//bloqueado un minuto
      j=0;
      }
      for(int d=0;d<10;d++)
      {
      output_high(PIN_C1);
      delay_ms(100);
      output_low(PIN_C1);
      delay_ms(100);
      output_low(PIN_C0);
      }
     
      }


}
}

}
if(INPUT(SWIT)==1){
output_HIGH(LED);
break;
}

}


