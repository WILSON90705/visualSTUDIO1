
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	float INT;
	float P_INT;
	int DIN;
	float CAPF;
	cout<<"dime el capital RESPECTIVO";
	cin>>DIN;
	cout<<"dime tu porcentaje de intereses";
	cin>>P_INT;
	INT=DIN*P_INT;
	if(INT>=7000){
		CAPF=DIN+INT;
				
	}
	cout<<"tu capital es"<<CAPF;



}
