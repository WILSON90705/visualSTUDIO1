#include <16f877A.h>
#fuses HS, NOWDT, NOPROTECT, BROWNOUT, PUT, NOLVP
#use delay(clock=20M,crystal)
#use i2c(Master,Fast=100000, sda=PIN_C4, scl=PIN_C3,force_sw)
#include "i2c_Flex_LCD.c"

void main(){
lcd_init(0x4E,16,2);
lcd_backlight_led(ON);
while (TRUE) {
   lcd_gotoxy(0,2);
  lcd_putc("RAMIREZ TAR20"); 
  lcd_gotoxy(3,1);
  lcd_putc("WILSON12");
}
}

