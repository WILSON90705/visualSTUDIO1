/*         
 Una persona desea iniciar un negocio, para lo cual piensa verificar cu�nto dinero 
 le prestara el banco por hipotecar su casa.
 Tiene una cuenta bancaria, pero no quiere disponer de ella a menos que el monto por hipotecar su casa
 sea muy peque�o.
 Si el monto de la hipoteca es menor que $1,000 000 entonces invertir� el 50% de la inversi�n total y
 un socio invertir� el otro 50%.
 Si el monto de la hipoteca es de $ 1,000 000 o m�s, entonces invertir� el monto total de la hipoteca
 y el resto del dinero que se necesite para cubrir la inversi�n total se repartir� a partes iguales entre el socio
 y el
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int total,hipoteca,inversion;
	int TOTAL_NEGOCIO;
	cout<<"ingresa el monto total del negocio";
	cin>>TOTAL_NEGOCIO;
	cout<<"dime el monto de la hipoteca";
	cin>>hipoteca;
	if(hipoteca<=1000000){
		inversion=TOTAL_NEGOCIO*0.50;
		cout<<"tu el monto de la inversion de cada socio es"<<inversion;
	}
	else if(hipoteca>=1000000){
		inversion=(TOTAL_NEGOCIO-hipoteca)/2;
		cout<<"el monto inversion es "<<inversion;
	}
}

