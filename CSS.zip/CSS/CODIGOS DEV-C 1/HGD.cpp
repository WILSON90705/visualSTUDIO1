/*
En un supermercado se hace una promoci�n
mediante la cual el cliente obtiene un descuento dependiendo de un n�mero que se escoge al azar.
Si el numero escogido es menor que 74 el descuento es del 15% sobre el total de la compra, si es mayor o igual a 74 el descuento es del 20%
Obtener cu�nto dinero se le descuenta.
*/
#include<iostream>
#include <conio.h>
using namespace std;
int main(){
int TOT;
int NUM;
float DESC;
cout<<"dime el numero";
cin>>NUM;
cout<<"dime el TOTal de tu compra";
cin>>TOT;
if(NUM<74){
DESC=TOT*0.15;
}	
else if(NUM>=74){
DESC=TOT*0.15;
}
cout<<"tu descuento es"<<DESC;		
}
