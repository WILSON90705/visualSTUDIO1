/*
Calcular el n�mero de pulsaciones que debe tener una persona por cada 10 segundos de ejercicio aer�bico;
la formula que se aplica cuando el sexo es femenino es:
num_pulsaciones = (220 - edad)/10;
y si el sexo es masculino:
num_pulsaciones = (210 - edad)/10;
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	char a;
	double num_pulsaciones;
	int edad;
	cout<<"dime por favor con una M SI ERES (HOMBRE) y F SI ERES (MUJER)";
	cin>>a;
	cout<<"dime tu edad por favor";
	cin>>edad;
	if(a=='M'){
		num_pulsaciones = (210 - edad)/10;
	}
	else if (a=='F'){
		
	num_pulsaciones = (220 - edad)/10;	
	}
	cout<<"TUS PULSACIONES SON"<<num_pulsaciones;
}
