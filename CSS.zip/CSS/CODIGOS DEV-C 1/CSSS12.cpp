 /* Hacer un algoritmo que calcule el total a pagar por la compra de camisas  
  Si se compran tres camisas o mas se aplica un descuento del 20% sobre el total de la compra y si son menos de tres camisas un descuento del 10%
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
int NUM;
int precio;
float  total;
int compra;
int COMP;
int TOTAL_COMP;
cout<<"dime el numero de camisas";
cin>>NUM;
cout<<"dime la compra de las camisas";
cin>>COMP;
total=NUM*COMP;
if(NUM>=3){
TOTAL_COMP=total-total*0.20;
cout<<"tu compra es"<<TOTAL_COMP;
}
else {
       TOTAL_COMP=total-total*0.10;
       cout<<"tu compra es"<<TOTAL_COMP;
}



}
