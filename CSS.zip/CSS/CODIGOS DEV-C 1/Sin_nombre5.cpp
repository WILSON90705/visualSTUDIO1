/*                 
Determinar la cantidad de dinero que recibir� un trabajador por concepto de las horas extras trabajadas en una
empresa,sabiendo que cuando las horas de trabajo exceden de 40, el resto se consideran horas extras y que estas se pagan 
al doble de una hora normal cuando no exceden de 8;
si las horas extras exceden de 8 se pagan las primeras 8 al doble de lo que se pagan las horas normales y el resto al triple.
*/
#include<iostream>
#include <conio.h>
using namespace std;
int main(){
	int HORAS_TRABAJADAS;
	float HEX;
	int PXH;
	float DINERO;
	float PE;	
	int pd;
	float PT;
	float tp;
	cout<<"dime las horas del trabajo";
	cin>>HORAS_TRABAJADAS;
	cout<<"dime el pago de las horas";
	cin>>PXH;
	cout<<"dime tus HORAS EXTRAS";
	cin>>HEX;
	if(HORAS_TRABAJADAS<=40){
	DINERO=HORAS_TRABAJADAS*PXH;
}
else{
	HEX=HORAS_TRABAJADAS-40;
	if(HEX<=8){
		
		PE=HORAS_TRABAJADAS*PXH*2;
	}
	else{
		pd=3*PXH*2;
		PT = (HEX-8)*PXH*3;
		PE=pd+PT;
	}
	tp = 40*PXH + PE;
}
	cout<<"los pagos son"<<DINERO;
	
}
