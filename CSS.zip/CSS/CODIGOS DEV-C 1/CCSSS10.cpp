/*              
El IMSS requiere clasificar a las personas que se jubilaran en el a�o de 1997.
Existen tres tipos de jubilaciones: por edad, por antig�edad joven y por antig�edad adulta.
Las personas adscritas a la jubilaci�n por edad deben tener 60 a�os o m�s y una antig�edad en su empleo de menos de 25 a�os. 
Las personas adscritas a la jubilaci�n por antig�edad adulta deben tener 60 a�os o m�s y una antig�edad en su empleo de 25 a�os o m�s.
Determinar en qu� tipo de jubilaci�n, quedara adscrita una persona.
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int ANT;
	int EDAD;
	cout<<"dime LA EDAD DEL SE�OR";
	cin>>EDAD;
	cout<<"dime LA antiguedad DEL SENOR";
	cin>>ANT;
	if(EDAD>=60 && ANT<25){
		cout<<"TIENES JUBILACION ADSCRITA POR EDAD";
	}
else if(EDAD>=60 && EDAD>=25){
	
	cout<<"tienes JUBILACION ADSCRITA POR ANTIGUEDAD";	
}	
}
