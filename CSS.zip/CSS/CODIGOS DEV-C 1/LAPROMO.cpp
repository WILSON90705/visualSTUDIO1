#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int contador=0;
	int acumulador=0;
	int cuenta=0;
	int promedio;
	cout<<"dime por favor tus notas";
	cin>>contador;
	for(int contador=1;contador<3;contador++){
		acumulador=acumulador+contador;
		cuenta=cuenta+1;
	}
	promedio=acumulador/cuenta;
	cout<<"ttu  promeddio es"<<promedio;
}
