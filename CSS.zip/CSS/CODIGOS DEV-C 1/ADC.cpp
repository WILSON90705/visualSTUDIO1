/*
Calcular el n�mero de pulsaciones que debe tener una persona por cada 10 segundos de ejercicio aer�bico
la formula que se aplica cuando el sexo es femenino es
num_pulsaciones = (220 - edad)/10 y si el sexo es masculino: num_pulsaciones = (210 - edad)/10
*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
char A[5];
for(int i=0;i<=5;i++){
	cout<<"dime tu sexo";
	cin>>A[i];
}	
	
	
	
	
	
}
