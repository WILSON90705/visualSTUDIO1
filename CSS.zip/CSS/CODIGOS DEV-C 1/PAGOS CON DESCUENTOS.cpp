#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int KILOS;
	float PAGO;
	int costo;
	cout<<"dime por favor el numero de kilos";
	cin>>KILOS;
	cout<<"dime por favor el costo de los numeros kilos";
	cin>>costo;
	if(KILOS>=0 && KILOS<=2){
		PAGO=costo;
	}
	else if(KILOS>=2 && KILOS<=5){
		PAGO=costo*0.10;
	}
	else if(KILOS>=5 && KILOS<=10){
		PAGO=costo*0.15;
	}
	else if(KILOS>10){
		PAGO=costo*0.20;
	}
	cout<<"lo que debes pagar es"<<PAGO;
}
