#include <iostream>
#include <conio.h>
using namespace std;

int main(){
	int a;
	cout<<"dime una OPCION";
	cin>>a;
	switch(a){
		case 1:cout<<"HOLA";
		break;
		case 2:cout<<"como estas";
		break;
		default:cout<<"no escribiste nigun mensaje";
	 break;
	}

}
