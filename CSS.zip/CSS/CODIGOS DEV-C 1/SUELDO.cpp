/*
determinar la cantidad del bono navide�o que recibir� un empleado de una tienda,
considerando que si su antig�edad es mayor a cuatro a�os o su sueldo es menor de dos mil pesos,
le corresponder� 25 % de su sueldo, y en caso contrario s�lo le corresponder� 20 % de �ste.
*/

#include<iostream>
#include<conio.h>
using namespace std;
int main(){
float SUELDO;
int ANTIGUEDAD;
cout<<"dime porfavor el sueldo";
cin>>SUELDO;	
cout<<"DIME LA ANTIGUEDAD EN DICHO LOCAL";
cin>>ANTIGUEDAD;
	if(SUELDO<2000||ANTIGUEDAD>4){
		SUELDO=SUELDO*0.25;
	}
	else{
		
		SUELDO=SUELDO*0.20;
	}
	cout<<"TU SUELDO ES"<<SUELDO;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
