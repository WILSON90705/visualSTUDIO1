#include <16F874A.h>
#fuses HS,NOWDT,PUT,NOPROTECT
#INT_EXT
#use delay(crystal=8000000)

void ext_isr(void){
 output_toggle(PIN_B0);
}

void main(){
  output_low(PIN_B0);
  ext_int_edge(H_TO_L);             // Interrupci�n
  clear_interrupt(INT_EXT);       // interrupci�n externa RB0
  enable_interrupts(INT_EXT);   // Habilitar interrupci�n externa RB0 / INT
  enable_interrupts(GLOBAL);   // Habilitar todas las interrupciones
  while(TRUE);                          // Ciclo infinito
}  

