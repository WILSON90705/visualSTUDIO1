/* Hacer un algoritmo que imprima el nombre de un art�culo, clave, precio original y su precio con descuento 
 El descuento lo hace en base a la clave, si la clave es 01 el descuento es del 10% y si la clave es 02 el descuento en del 20% (solo existen dos claves).*/
#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int CLAVE;
    char NOMBRE[10];
	int PRECIO;
	int PRECIO_DESC;
	cout<<"dime la clave del dispositivo por favor";
	cin>>CLAVE;
	cout<<"dime el precio";
	cin>>PRECIO;
	for(int i=0;i<10;i++){
		cout<<"DIME EL PRODUCTO";
		cin>>NOMBRE[i];
	}
	for(int i=0;i<10;i++)
 {
 cout<<"\n NOMBRE["<<i<<"]="<<NOMBRE[i];
 }
	if(CLAVE==01){
		PRECIO_DESC=PRECIO*0.10;
	}
	else if(CLAVE==02){
		PRECIO_DESC=PRECIO*0.20;
	}
	cout<<"TU NOMBRE DE PRODUCTO"<<endl;
	cout<<"tu precio descontado es"<<PRECIO_DESC<<endl;
	cout<<"tu precio ORIGINAL es"<<PRECIO<<endl;
	
}
