#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	int suma=0;
	int cuenta=0;
	float promedio;
	int notas=0;
	int acumulador=0;
	float n;
	cout<<"dime el numero de notas";
	cin>>n;
	cuenta=0;
	while(cuenta<n){
		cout<<"tu notas dimelas";
		cin>>notas;
		acumulador+=notas;
		cuenta++;
	}
	promedio=acumulador/n;
	cout<<"TUS PROM SON"<<promedio;
	
	
}
