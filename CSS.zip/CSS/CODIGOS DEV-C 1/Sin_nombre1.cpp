#include <iostream>
#include <conio.h>
#include <cmath>
using namespace std;
int main(){
	int pinos;
	int  oyameles;
    int cedros;
	int MTS_C;
	cout<<"dime por favor cuantos metros cuadrados tienes";
	cin>>MTS_C;
	if(MTS_C>=1000000){
		pinos=MTS_C*.70;
		oyameles=MTS_C*.20;
		cedros=MTS_C*.10;
	}
	else if(MTS_C<1000000){
		pinos=MTS_C*.50;
		oyameles=MTS_C*.30;
		cedros=MTS_C*.20;
	}	
	cout<<"El n�mero de arboles pinos que se pueden sembrar en "<<pinos<<" metros es "<<trunc((pinos/10)*8);
	cout<<"el numero de oyameles que se pueden sembrar en "<<oyameles<<" metros es "<<trunc(oyameles);
    cout<<"el numero de cedros que se pueden sembrar en"<<cedros<<"metros es"<<trunc((cedros/18)*10);
	}
