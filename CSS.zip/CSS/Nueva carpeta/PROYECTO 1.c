#include <16f887.h>
#fuses HS, NOWDT, PUT, NOMCLR,BROWNOUT,NOLVP
#use delay(clock=20MHz)
/*
#define LCD_DB4 pin_D4
#define LCD_DB5 PIN_D5
#define LCD_DB6 PIN_D6
#define LCD_DB7 PIN_D7
#define LCD_RS PIN_D1
#define LCD_RW PIN_D2
#define LCD_E PIN_D0*/
#include <lcd.c>

void MAIN()
{
   lcd_init();          
   while(true)
   {
   lcd_gotoxy(1,1);
printf(lcd_putc,"  BIENVENIDO ");
lcd_gotoxy(1,2);
printf(lcd_putc,"\n sistema alarma ");
delay_ms(100);
lcd_putc("\f");
break;
   } 
}
